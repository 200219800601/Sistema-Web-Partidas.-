// jQuery
$(document).ready(function(){
    $(document.getElementsByName("btn_info")).click(function(){
      $(document.getElementsByName("info")).toggle('slow');
    });
  });