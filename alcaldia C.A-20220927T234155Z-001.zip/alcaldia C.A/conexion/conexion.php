<?php

$servidor = "localhost";
$usuario = "root";
$contra = "";
$base_datos = "amca";



?>